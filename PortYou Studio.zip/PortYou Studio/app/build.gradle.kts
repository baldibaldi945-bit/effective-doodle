plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.portyou.studio"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.portyou.studio"
        minSdk = 23
        targetSdk = 34
        versionCode = 5
        versionName = "0.5.0"
    }
    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
            signingConfig = signingConfigs.getByName("debug")   // personal builds; replace for Play Store
        }
    }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
    androidResources { noCompress += listOf("ogg", "mp4", "zip", "png") }
    packaging { resources.excludes += listOf("META-INF/*.kotlin_module", "META-INF/DEPENDENCIES", "META-INF/LICENSE*", "META-INF/NOTICE*") }
}
dependencies {
    implementation("androidx.documentfile:documentfile:1.0.1")
    implementation("org.apache.commons:commons-compress:1.26.2")   // 7z
    implementation("org.tukaani:xz:1.9")                           // 7z (LZMA)
    implementation("com.github.junrar:junrar:7.5.5")               // rar
}
