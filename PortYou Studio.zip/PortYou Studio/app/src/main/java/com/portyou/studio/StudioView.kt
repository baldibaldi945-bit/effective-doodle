package com.portyou.studio

import android.content.Context
import android.graphics.*
import android.os.SystemClock
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import android.view.MotionEvent
import android.view.View
import org.json.JSONObject
import kotlin.math.min

/** Draws every screen as stacked 1080x1920 art layers, letter-boxed; touch zones come from the art's alpha. */
class StudioView(ctx: Context, private val prefs: Prefs, private val sound: Sound, private val host: Host) : View(ctx) {

    interface Host {
        fun pickMod(kind: Int)            // 0 = V-Slice, 1 = Funky Maker
        fun openUrl(url: String)
        fun onSuccessOk()
    }
    enum class Screen { MAIN, SETTINGS, LOADING, SUCCESS, FAIL }
    enum class Sub { NONE, LANG, DESC, SOUND }

    var screen = Screen.MAIN; private set
    private var mainImg = 1
    private var sub = Sub.NONE
    private var selected: String? = null
    private var langAnimStart = 0L
    private var bubbleText = ""
    private var failText: String? = null

    private val layout = HashMap<String, IntArray>()
    private val bmps = HashMap<String, Bitmap>()
    private var scale = 1f; private var offX = 0f; private var offY = 0f
    private val paint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
    private val text = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.BLACK; typeface = Typeface.DEFAULT_BOLD }
    private val whitePaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; typeface = Typeface.DEFAULT_BOLD }

    init {
        val j = JSONObject(context.assets.open("ui/layout.json").bufferedReader().readText())
        for (k in j.keys()) { val a = j.getJSONArray(k); layout[k] = IntArray(4) { a.getInt(it) } }
        setBackgroundColor(Color.BLACK)
    }

    private fun bmp(name: String): Bitmap {
        bmps[name]?.let { return it }
        val l = layout[name]!!
        val o = BitmapFactory.Options()
        var s = 1
        while (l[2] / (s * 2) >= l[2] * scale && s < 8) s *= 2     // decode no bigger than needed
        o.inSampleSize = s
        val b = context.assets.open("ui/$name.png").use { BitmapFactory.decodeStream(it, null, o)!! }
        bmps[name] = b; return b
    }
    private fun retain(keep: Set<String>) {
        val it = bmps.entries.iterator()
        while (it.hasNext()) { val e = it.next(); if (e.key !in keep) { e.value.recycle(); it.remove() } }
    }

    // ---------------- state changes ----------------
    fun showMain() { screen = Screen.MAIN; mainImg = 1; sub = Sub.NONE; selected = null; invalidate() }
    fun showLoading() { screen = Screen.LOADING; retain(setOf("black", loadingName())); invalidate() }
    fun showSuccess() { screen = Screen.SUCCESS; sound.play("sfx_success"); invalidate() }
    fun showFail() {
        screen = Screen.FAIL; sound.play("sfx_fail"); invalidate()
    }
    fun enterSettings() {
        screen = Screen.SETTINGS; sub = Sub.NONE; selected = null
        val a = Strings.akram[prefs.lang]; bubbleText = a[prefs.phraseIdx % a.size]; invalidate()
    }
    fun leaveSettings() { prefs.phraseIdx = prefs.phraseIdx + 1; showMain() }
    private fun loadingName() = if (Strings.isArabic(prefs.lang)) "loading_ar" else "loading_en"

    // ---------------- geometry ----------------
    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        scale = min(w / 1080f, h / 1920f); offX = (w - 1080 * scale) / 2f; offY = (h - 1920 * scale) / 2f
        retain(emptySet())
    }
    private fun dx(x: Float) = (x - offX) / scale
    private fun dy(y: Float) = (y - offY) / scale

    private fun draw(c: Canvas, name: String, ox: Float = 0f, oy: Float = 0f, alpha: Float = 1f) {
        val l = layout[name]!!; val b = bmp(name)
        paint.alpha = (alpha * 255).toInt()
        c.drawBitmap(b, null, RectF(l[0] + ox, l[1] + oy, l[0] + ox + l[2], l[1] + oy + l[3]), paint)
    }
    private fun hit(name: String, x: Float, y: Float, ox: Float = 0f): Boolean {
        val l = layout[name]!!
        val lx = x - ox - l[0]; val ly = y - l[1]
        if (lx < 0 || ly < 0 || lx >= l[2] || ly >= l[3]) return false
        val b = bmp(name)
        val px = (lx * b.width / l[2]).toInt().coerceIn(0, b.width - 1)
        val py = (ly * b.height / l[3]).toInt().coerceIn(0, b.height - 1)
        return Color.alpha(b.getPixel(px, py)) > 40
    }
    private fun centered(c: Canvas, s: String, p: TextPaint, x: Float, y: Float, w: Float, size: Float) {
        p.textSize = size
        @Suppress("DEPRECATION")
        val sl = StaticLayout(s, p, w.toInt(), Layout.Alignment.ALIGN_CENTER, 1f, 0f, false)
        c.save(); c.translate(x, y + (0).toFloat()); sl.draw(c); c.restore()
    }

    // ---------------- drawing ----------------
    private fun langOffset(): Float {
        if (sub != Sub.LANG) return 0f
        val t = ((SystemClock.uptimeMillis() - langAnimStart) / 250f).coerceIn(0f, 1f)
        if (t < 1f) postInvalidateOnAnimation()
        return 560f * (1f - (1f - t) * (1f - t))
    }
    private fun dim(key: String) = if (selected != null && selected != key && key != "btn_youtube" && key != "btn_insta") 0.4f else 1f

    override fun onDraw(c: Canvas) {
        c.drawColor(Color.BLACK)
        c.save(); c.translate(offX, offY); c.scale(scale, scale)
        c.clipRect(0f, 0f, 1080f, 1920f)
        when (screen) {
            Screen.MAIN -> { retain(setOf("main$mainImg")); draw(c, "main$mainImg") }
            Screen.SETTINGS -> drawSettings(c)
            Screen.LOADING -> { draw(c, "black"); draw(c, loadingName()) }
            Screen.SUCCESS -> { draw(c, "black"); draw(c, "ok_tick"); draw(c, "ok_btn") }
            Screen.FAIL -> {
                draw(c, "black"); draw(c, "fail_icon")
                if (Strings.isArabic(prefs.lang)) draw(c, "fail_text_ar")
                else centered(c, Strings.unsupported[prefs.lang], whitePaint, 132f, 1195f, 784f, 54f)
                draw(c, "fail_ok")
            }
        }
        c.restore()
    }

    private fun drawSettings(c: Canvas) {
        draw(c, "set_bg")
        draw(c, "btn_sound", alpha = dim("btn_sound"))
        draw(c, "btn_desc", alpha = dim("btn_desc"))
        draw(c, "btn_lang", ox = langOffset(), alpha = dim("btn_lang"))
        draw(c, "btn_youtube"); draw(c, "btn_insta")
        when (sub) {
            Sub.LANG -> { draw(c, "lang_panel"); draw(c, "tick_lang", oy = prefs.lang * 159f) }
            Sub.DESC -> {
                draw(c, Strings.descImage(prefs.lang))
            }
            Sub.SOUND -> {
                draw(c, "set_sound_panel")
                if (prefs.sfxMuted) c.drawBitmap(bmp("tick_sound"), null, RectF(427f, 945f, 538f, 1043f), paint)
                if (prefs.musicMuted) c.drawBitmap(bmp("tick_sound"), null, RectF(397f, 1215f, 508f, 1313f), paint)
            }
            else -> {}
        }
        draw(c, "akram"); draw(c, "bubble")
        val tea = bubbleText == Strings.akram[prefs.lang].last()
        if (tea) {      // last saying: the small "fail" face sits on top of the bubble, text moves under it
            val ic = bmp("fail_icon")
            c.drawBitmap(ic, null, RectF(790f, 1168f, 910f, 1288f), paint)
            centered(c, bubbleText, text, 722f, 1300f, 290f, 34f)
        } else centered(c, bubbleText, text, 722f, 1215f, 290f, 34f)
    }

    // ---------------- touch ----------------
    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.actionMasked != MotionEvent.ACTION_DOWN) return true
        val x = dx(e.x); val y = dy(e.y)
        sound.play("sfx_click")
        when (screen) {
            Screen.MAIN -> touchMain(x, y)
            Screen.SETTINGS -> touchSettings(x, y)
            Screen.SUCCESS -> if (hit("ok_btn", x, y)) host.onSuccessOk()
            Screen.FAIL -> if (hit("fail_ok", x, y)) showMain()
            Screen.LOADING -> {}
        }
        return true
    }

    // Option zones on the right edge of main1 (design-space px)
    private fun touchMain(x: Float, y: Float) {
        if (mainImg != 1 || x < 740f) return
        when {
            y in 560f..960f -> { mainImg = 2; invalidate(); host.pickMod(0) }
            y in 1150f..1520f -> { mainImg = 3; invalidate(); host.pickMod(1) }
            y in 1580f..1900f -> { mainImg = 4; invalidate(); postDelayed({ enterSettings() }, 140) }
        }
    }

    private fun toggle(key: String, s: Sub) {
        if (selected == key) { selected = null; sub = Sub.NONE } else { selected = key; sub = s; if (s == Sub.LANG) langAnimStart = SystemClock.uptimeMillis() }
        invalidate()
    }

    private fun touchSettings(x: Float, y: Float) {
        // hidden/info elements first (topmost): Akram
        if (hit("akram", x, y)) { host.openUrl(AKRAM_YT); say(Strings.akram[prefs.lang].random()); return }
        if (hit("btn_youtube", x, y)) { host.openUrl(DEV_YT); say(Strings.ytSay[prefs.lang].random()); return }
        if (hit("btn_insta", x, y)) { host.openUrl(DEV_IG); say(Strings.instaSay[prefs.lang].random()); return }
        when {
            sub == Sub.LANG && x in 318f..620f && y in 835f..1745f -> {
                val row = ((y - 835f) / 159f).toInt().coerceIn(0, 5)
                prefs.lang = row; invalidate(); return
            }
            sub == Sub.SOUND && x in 360f..560f && y in 935f..1050f -> { prefs.sfxMuted = !prefs.sfxMuted; invalidate(); return }
            sub == Sub.SOUND && x in 360f..560f && y in 1205f..1320f -> { prefs.musicMuted = !prefs.musicMuted; sound.applyMusicSetting(); invalidate(); return }
        }
        when {
            hit("btn_lang", x, y, langOffset()) -> toggle("btn_lang", Sub.LANG)
            hit("btn_desc", x, y) -> toggle("btn_desc", Sub.DESC)
            hit("btn_sound", x, y) -> toggle("btn_sound", Sub.SOUND)
            else -> { selected = null; sub = Sub.NONE; invalidate() }   // tap elsewhere: restore everything
        }
    }
    private fun say(s: String) { bubbleText = s; invalidate() }

    companion object {
        const val DEV_YT = "https://youtube.com/@axelzerox023"
        const val DEV_IG = "https://www.instagram.com/axelzerox023"
        const val AKRAM_YT = "https://youtube.com/@akrammakak-official"
    }
}
