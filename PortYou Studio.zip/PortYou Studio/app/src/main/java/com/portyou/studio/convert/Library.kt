package com.portyou.studio.convert

import android.content.Context
import org.json.JSONObject
import java.util.zip.GZIPInputStream
import kotlin.math.max

/** Ready-made Psych Lua (custom events / note types) packed from the supplied script collection; used when Haxe cannot be translated. */
object Library {
    private var cache: JSONObject? = null
    private fun load(ctx: Context): JSONObject {
        cache?.let { return it }
        val t = GZIPInputStream(ctx.assets.open("converter/library.json.gz")).bufferedReader(Charsets.UTF_8).use { it.readText() }
        return JSONObject(t).also { cache = it }
    }
    private fun norm(s: String) = s.lowercase().replace(Regex("[^a-z0-9]"), "")
    private fun find(ctx: Context, group: String, name: String): String? {
        val g = load(ctx).optJSONObject(group) ?: return null
        val n = norm(name.removePrefix("extra-events-"))
        val want = setOf(n, n.removeSuffix("event"))
        for (k in g.keys()) { val nk = norm(k); if (nk in want || nk.removeSuffix("event") in want) return g.getString(k) }
        return null
    }
    fun event(ctx: Context, name: String): String? = try { find(ctx, "events", name) } catch (e: Exception) { null }
    fun noteType(ctx: Context, name: String): String? = try { find(ctx, "notetypes", name) } catch (e: Exception) { null }
    /** whole-song helper scripts (health drain, hold fixes, stage change manager ...) for scripts/<name>.lua */
    fun script(ctx: Context, name: String): String? = try { find(ctx, "scripts", name) } catch (e: Exception) { null }
    fun scriptNames(ctx: Context): List<String> = try { load(ctx).optJSONObject("scripts")?.keys()?.asSequence()?.toList() ?: emptyList() } catch (e: Exception) { emptyList() }

    /** words of a name: camelCase / snake / digits split, lower case */
    fun words(s: String): Set<String> =
        s.replace(Regex("([a-z0-9])([A-Z])"), "$1 $2").lowercase().split(Regex("[^a-z0-9]+")).filter { it.length >= 2 && it !in setOf("event", "extra", "events", "note", "type", "kind") }.toSet()

    private fun lcsRatio(a: String, b: String): Double {
        if (a.isEmpty() || b.isEmpty()) return 0.0
        var prev = IntArray(b.length + 1)
        for (i in 1..a.length) { val cur = IntArray(b.length + 1); for (j in 1..b.length) cur[j] = if (a[i - 1] == b[j - 1]) prev[j - 1] + 1 else max(prev[j], cur[j - 1]); prev = cur }
        return 2.0 * prev[b.length] / (a.length + b.length)
    }

    /** similarity 0..1: shared words (Jaccard) blended with the character-level ratio */
    fun similarity(a: String, b: String): Double {
        val wa = words(a); val wb = words(b)
        val j = if (wa.isEmpty() || wb.isEmpty()) 0.0 else wa.intersect(wb).size.toDouble() / wa.union(wb).size
        return max(j, lcsRatio(norm(a), norm(b)) * 0.95)
    }

    /** closest library script for an unknown name. The original name inside the script is rewritten to [name] so it still triggers. */
    fun nearest(ctx: Context, group: String, name: String, min: Double = 0.72): Pair<String, String>? = try {
        val g = load(ctx).optJSONObject(group)
        var best: String? = null; var bs = 0.0
        if (g != null) for (k in g.keys()) { val s = similarity(k, name); if (s > bs) { bs = s; best = k } }
        if (best != null && bs >= min) {
            val src = g!!.getString(best).replace("'$best'", "'$name'").replace("\"$best\"", "\"$name\"")
            src to best
        } else null
    } catch (e: Exception) { null }
}
