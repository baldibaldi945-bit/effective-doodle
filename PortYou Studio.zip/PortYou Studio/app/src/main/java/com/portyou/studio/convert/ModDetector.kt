package com.portyou.studio.convert

import java.io.File

enum class ModType { FUNKY_MAKER, VSLICE, UNKNOWN }

object ModDetector {
    /** Returns the type and the folder that is the mod's real root (archives often wrap everything in one folder). */
    private fun isFnmm(d: File) = File(d, "data.json").isFile && File(d, "scene.json").isFile

    fun detect(dir: File): Pair<ModType, File> {
        // 1. any folder (up to 6 levels deep) holding data.json + scene.json is a Funky Maker mod, whatever the archive wrapper looks like
        dir.walkTopDown().maxDepth(6).filter { it.isDirectory && !it.path.contains("__MACOSX") }.firstOrNull { isFnmm(it) }?.let { return ModType.FUNKY_MAKER to it }
        // 2. V-Slice: meta file anywhere, or charts/metadata/hxc files
        dir.walkTopDown().maxDepth(6).firstOrNull { it.isFile && it.name == "_polymod_meta.json" }?.let { return ModType.VSLICE to it.parentFile!! }
        val any = dir.walkTopDown().take(6000).toList()
        if (any.any { it.name.endsWith("-chart.json") || it.name.endsWith("-metadata.json") || it.extension == "hxc" })
            return ModType.VSLICE to dir
        return ModType.UNKNOWN to dir
    }
}
